﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace forrat5var
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
        private List<string> items = new List<string>();
        private List<string> items2 = new List<string>();
        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            if (File.Exists("words.txt"))
            {
                string file = File.ReadAllText("words.txt");
                if (!string.IsNullOrEmpty(file))
                {
                    string[] fromfile = file.Split(' ', (char)StringSplitOptions.RemoveEmptyEntries);

                    foreach (var v in fromfile)
                    {
                        items.Add(v);
                        listBox1.Items.Add(v);
                    }

                    var rez = fromfile.Select(word => $"{word}: {word[0]}");
                    foreach (var k in rez)
                    {
                        items2.Add(k);
                        listBox2.Items.Add(k);
                    }
                    
                }
                else MessageBox.Show("Файл пустой!");
            }
            else MessageBox.Show("Файл не найден!");


        }
      
        private void button3_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            char letter = textBox2.Text[0];
      
            foreach (string word in items)
            {
                if (!string.IsNullOrEmpty(word) && char.ToLower(word[0]) == char.ToLower(letter)) {
                    items.Remove(word);
                    break;
                }
            
            }
            var rez = items.Select(word => $"{word}: {word[0]}");
            foreach (var k in rez)
            {
                items2.Add(k);
                listBox3.Items.Add(k);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            listBox4.Items.Clear();
            items.Add(textBox1.Text);
            foreach (var c in items)
            {

                listBox4.Items.Add(c);
            }
        }
    }
}
